create trigger checkIsNewDis
  before INSERT
  on recognition
  for each row
BEGIN
    IF (SELECT visit_ID
        FROM recognition
        WHERE visit_ID = NEW.visit_ID AND disease = NEW.disease) IS NOT NULL
    THEN
      SIGNAL SQLSTATE '23456'
      SET MESSAGE_TEXT = 'check isNew failed';
    END IF;
  END;

