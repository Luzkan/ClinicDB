create trigger checkDoctorOfficeHour
  before INSERT
  on visits
  for each row
BEGIN
    IF NOT (
      CAST(NEW.time AS TIME) > (
        SELECT CAST(H.beginning AS TIME)
        FROM Doctors D
          JOIN `Office Hours` H ON D.PWZ = H.doctor
        WHERE D.PWZ = NEW.Doctor AND H.day = (DAYNAME(NEW.date)))
      AND
      CAST(NEW.time AS TIME) < (
        SELECT CAST(H.end AS TIME)
        FROM Doctors D
          JOIN `Office Hours` H ON D.PWZ = H.doctor
        WHERE D.PWZ = NEW.Doctor AND H.day = (DAYNAME(NEW.date))))
    THEN
      SIGNAL SQLSTATE '12345'
      SET MESSAGE_TEXT = 'check constraint on Office Hours failed';
    END IF;

    IF NEW.date < CURRENT_DATE AND NEW.time < CURRENT_TIME
    THEN
      SIGNAL SQLSTATE '12345'
      SET MESSAGE_TEXT = 'check constraint on Visits-date failed';
    END IF;
  END;

