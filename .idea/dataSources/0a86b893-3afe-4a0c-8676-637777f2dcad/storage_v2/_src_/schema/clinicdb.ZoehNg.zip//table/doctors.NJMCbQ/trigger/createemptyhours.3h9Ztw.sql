create trigger createEmptyHours
  after INSERT
  on doctors
  for each row
BEGIN
INSERT INTO `office hours` (`doctor`, `day`, `beginning`, `end`) VALUES (NEW.PWZ, 'Monday', '00:00:00', '00:00:00');
INSERT INTO `office hours` (`doctor`, `day`, `beginning`, `end`)
VALUES (NEW.PWZ, 'Tuesday', '00:00:00', '00:00:00');
INSERT INTO `office hours` (`doctor`, `day`, `beginning`, `end`)
VALUES (NEW.PWZ, 'Wednesday', '00:00:00', '00:00:00');
INSERT INTO `office hours` (`doctor`, `day`, `beginning`, `end`)
VALUES (NEW.PWZ, 'Thursday', '00:00:00', '00:00:00');
INSERT INTO `office hours` (`doctor`, `day`, `beginning`, `end`) VALUES (NEW.PWZ, 'Friday', '00:00:00', '00:00:00');
INSERT INTO `office hours` (`doctor`, `day`, `beginning`, `end`)
VALUES (NEW.PWZ, 'Saturday', '00:00:00', '00:00:00');
INSERT INTO `office hours` (`doctor`, `day`, `beginning`, `end`) VALUES (NEW.PWZ, 'Sunday', '00:00:00', '00:00:00');
END;

