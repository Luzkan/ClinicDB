create trigger checkTime
  before UPDATE
  on `office hours`
  for each row
BEGIN
    IF NEW.beginning > NEW.end
    THEN
      SIGNAL SQLSTATE '12345'
      SET MESSAGE_TEXT = 'check constraint on Office Hours failed';
    END IF;
  END;

