create trigger checkIsNewMed
  before INSERT
  on prescription
  for each row
BEGIN
    IF (SELECT visit_ID
        FROM prescription
        WHERE visit_ID = NEW.visit_ID AND medicine = NEW.medicine) IS NOT NULL
    THEN
      SIGNAL SQLSTATE '23456'
      SET MESSAGE_TEXT = 'check isNew failed';
    END IF;
  END;

